-- Generated from remade GGL config.
BindPadBulkImporterDataText = [==[
#bindpad

#general

[TargetMouseOver]
@bind ALT-SHIFT-1
/target mouseover

[TargetEnemy]
@bind ALT-SHIFT-2
/targetenemy

[TargetLastTarget]
@bind ALT-SHIFT-3
/targetlasttarget

[Target Arena1]
@bind ALT-SHIFT-4
/target arena1

[Target Arena2]
@bind ALT-SHIFT-5
/target arena2

[Target Arena3]
@bind ALT-SHIFT-6
/target arena3

[Target Arena4]
@bind ALT-SHIFT-7
/target arena4

[Target Arena5]
@bind ALT-SHIFT-8
/target arena5

[Focus Arena1]
@bind ALT-SHIFT-9
/focus arena1

[Focus Arena2]
@bind ALT-SHIFT-0
/focus arena2

[Focus Arena3]
@bind ALT-SHIFT-A
/focus arena3

[Focus Arena4]
@bind ALT-SHIFT-B
/focus arena4

[Focus Arena5]
@bind ALT-SHIFT-C
/focus arena5

[Focus Party1]
@bind ALT-SHIFT-D
/focus party1

[Focus Party2]
@bind ALT-SHIFT-E
/focus party2

[Focus Party3]
@bind ALT-SHIFT-F
/focus party3

[Focus Party4]
@bind ALT-SHIFT-G
/focus party4

[Focus Player]
@bind ALT-SHIFT-H
/focus player

[StopCasting]
@bind ALT-SHIFT-I
/stopcasting

[StartAttack]
@bind ALT-SHIFT-J
/startattack [@mouseover,harm][@targettarget,harm][]
/petattack [@mouseover,harm][]

[Trinket1]
@bind ALT-SHIFT-K
/use 13

[Trinket2]
@bind ALT-SHIFT-L
/use 14

[HealthStone]
@bind ALT-SHIFT-M
/use Fel Healthstone
/use Demonic Healthstone
/use Master Healthstone
/use Major Healthstone
/use Greater Healthstone
/use Healthstone
/use Lesser Healthstone
/use Minor Healthstone

[HealingPotion]
@bind ALT-SHIFT-N
/use item:244849
/use item:244839
/use item:244838
/use item:244835
/use item:212318
/use item:211880
/use item:212944
/use item:212943
/use item:211879
/use item:212942
/use item:211878
/use item:191380
/use item:191379
/use item:191378
/use item:187802
/use item:171267

[Whipper Root Tuber]
@bind ALT-SHIFT-O
/use item:11951

[SBA]
@bind ALT-SHIFT-P
/cast Single-Button Assistant

#character

[Warrior - Arms - SwapWeapon]
@bind ALT-SHIFT-1
/stopcasting
/equipslot [noworn:shield] 16 one-main-hand
/equipslot [noworn:shield] 17 shield
/equip two-hander

Macro for swap between dual one hand to shield+one hand:
/stopcasting
/equipslot [noworn:shield] 16 one-main-hand
/equipslot [noworn:shield] 17 shield
/equipslot [worn:shield,noworn:two-hand] 16 one-main-hand
/equipslot [worn:shield] 17 one-off-hand
Note: When making this macro you'll need to replace one-hander, shield, and two-hander with the names of the weapons that your character is specifically using. For instance, if you were using Obsidian Edged Blade you would write Obsidian Edged Blade instead of two-hander
[shield] must be localized to your native language too!!!
 IconID: 132996, spellID: 20219

[3->4] meta slots

[Warrior - Arms - Battle Shout]
@bind ALT-SHIFT-2
/startattack
/cast Battle Shout

[Warrior - Arms - Berserker Roar | Berserker Shout | Berserker Rage]
@bind ALT-SHIFT-3
/cast Berserker Roar
/cast Berserker Shout
/cast Berserker Rage

[Warrior - Arms - Charge]
@bind ALT-SHIFT-4
/startattack
/cast [@mouseover,harm][]Charge

[Warrior - Arms - Charge Arena1]
@bind ALT-SHIFT-5
/cast [@arena1]Charge

[Warrior - Arms - Charge Arena2]
@bind ALT-SHIFT-6
/cast [@arena2]Charge

[Warrior - Arms - Charge Arena3]
@bind ALT-SHIFT-7
/cast [@arena3]Charge

[Warrior - Arms - Charge Arena4]
@bind ALT-SHIFT-8
/cast [@arena4]Charge

[Warrior - Arms - Charge Arena5]
@bind ALT-SHIFT-9
/cast [@arena5]Charge

[Warrior - Arms - Execute]
@bind ALT-SHIFT-0
/cast Execute

[Warrior - Arms - Hamstring]
@bind ALT-SHIFT-A
/cast Hamstring

[Warrior - Arms - Heroic Throw]
@bind ALT-SHIFT-B
/cast Heroic Throw

[Warrior - Arms - Interrupt]
@bind ALT-SHIFT-C
/stopcasting
/cast [@mouseover,harm][]Pummel

[Warrior - Arms - Interrupt Focus]
@bind ALT-SHIFT-D
/stopcasting
/cast [@focus]Pummel

[Warrior - Arms - Interrupt Arena1]
@bind ALT-SHIFT-E
/stopcasting
/cast [@arena1]Pummel
/cast [@arena1]Hamstring
/cast [@arena1]Titanic Throw
/cast [@arena1]Heroic Throw

[Warrior - Arms - Interrupt Arena2]
@bind ALT-SHIFT-F
/stopcasting
/cast [@arena2]Pummel
/cast [@arena2]Hamstring
/cast [@arena2]Titanic Throw
/cast [@arena2]Heroic Throw

[Warrior - Arms - Interrupt Arena3]
@bind ALT-SHIFT-G
/stopcasting
/cast [@arena3]Pummel
/cast [@arena3]Hamstring
/cast [@arena3]Titanic Throw
/cast [@arena3]Heroic Throw

[Warrior - Arms - Interrupt Arena4]
@bind ALT-SHIFT-H
/stopcasting
/cast [@arena4]Pummel
/cast [@arena4]Hamstring
/cast [@arena4]Titanic Throw
/cast [@arena4]Heroic Throw

[Warrior - Arms - Interrupt Arena5]
@bind ALT-SHIFT-I
/stopcasting
/cast [@arena5]Pummel
/cast [@arena5]Hamstring
/cast [@arena5]Titanic Throw
/cast [@arena5]Heroic Throw

[Warrior - Arms - Shield Block]
@bind ALT-SHIFT-J
/startattack
/cast Shield Block

[Warrior - Arms - Shield Slam]
@bind ALT-SHIFT-K
/cast Shield Slam

[Warrior - Arms - Slam]
@bind ALT-SHIFT-L
/cast Slam

[Warrior - Arms - Taunt]
@bind ALT-SHIFT-M
/cast [@mouseover,harm][]Oppressor
/cast [@mouseover,harm][]Taunt

[Warrior - Arms - Taunt Pets]
@bind ALT-SHIFT-N
/stopcasting
/cast [@arenapet1,harm]Oppressor
/cast [@arenapet2,harm]Oppressor
/cast [@arenapet3,harm]Oppressor
/cast [@arenapet4,harm]Oppressor
/cast [@arenapet5,harm]Oppressor
/cast [@arenapet1,harm]Taunt
/cast [@arenapet2,harm]Taunt
/cast [@arenapet3,harm]Taunt
/cast [@arenapet4,harm]Taunt
/cast [@arenapet5,harm]Taunt

[Warrior - Arms - Taunt Unit1]
@bind ALT-SHIFT-O
/stopcasting
/cast [@raidpet1,harm][@raid1,harm][@partypet1,harm][@party1,harm][@arenapet1,harm][@arena1]Oppressor
/cast [@raidpet1,harm][@raid1,harm][@partypet1,harm][@party1,harm][@arenapet1,harm][@arena1]Taunt

[Warrior - Arms - Taunt Unit2]
@bind ALT-SHIFT-P
/stopcasting
/cast [@raidpet2,harm][@raid2,harm][@partypet2,harm][@party2,harm][@arenapet2,harm][@arena2]Oppressor
/cast [@raidpet2,harm][@raid2,harm][@partypet2,harm][@party2,harm][@arenapet2,harm][@arena2]Taunt

[Warrior - Arms - Taunt Unit3]
@bind ALT-SHIFT-Q
/stopcasting
/cast [@raidpet3,harm][@raid3,harm][@partypet3,harm][@party3,harm][@arenapet3,harm][@arena3]Oppressor
/cast [@raidpet3,harm][@raid3,harm][@partypet3,harm][@party3,harm][@arenapet3,harm][@arena3]Taunt

[Warrior - Arms - Taunt Unit4]
@bind ALT-SHIFT-R
/stopcasting
/cast [@raidpet4,harm][@raid4,harm][@partypet4,harm][@party4,harm][@arenapet4,harm][@arena4]Oppressor
/cast [@raidpet4,harm][@raid4,harm][@partypet4,harm][@party4,harm][@arenapet4,harm][@arena4]Taunt

[Warrior - Arms - Taunt Unit5]
@bind ALT-SHIFT-S
/stopcasting
/cast [@raidpet5,harm][@raid5,harm][@pet,harm][@arenapet5,harm][@arena5]Oppressor
/cast [@raidpet5,harm][@raid5,harm][@pet,harm][@arenapet5,harm][@arena5]Taunt

[Warrior - Arms - Impending Victory | Victory Rush]
@bind ALT-SHIFT-T
/cast Impending Victory
/cast Victory Rush

[Warrior - Arms - Whirlwind]
@bind ALT-SHIFT-U
/cast Whirlwind

[Warrior - Arms - Battle Stance]
@bind ALT-SHIFT-V
/cast Battle Stance

[Warrior - Arms - Defensive Stance]
@bind ALT-SHIFT-W
/cast Defensive Stance

[Warrior - Arms - Intervene]
@bind ALT-SHIFT-X
/stopcasting
/cast [@mouseover,help][@focus,help][]Intervene

[Warrior - Arms - Intervene Member1]
@bind ALT-SHIFT-Y
/run GetLOS(UnitExists('raid1') and 'raid1' or 'party1')
/cast [@raid1,exists][@party1,exists]Intervene

[Warrior - Arms - Intervene Member2]
@bind ALT-SHIFT-Z
/run GetLOS(UnitExists('raid2') and 'raid2' or 'party2')
/cast [@raid2,exists][@party2,exists]Intervene

[Warrior - Arms - Intervene Member3]
@bind CTRL-SHIFT-1
/run GetLOS(UnitExists('raid3') and 'raid3' or 'party3')
/cast [@raid3,exists][@party3,exists]Intervene

[Warrior - Arms - Intervene Member4]
@bind CTRL-SHIFT-2
/run GetLOS(UnitExists('raid4') and 'raid4' or 'party4')
/cast [@raid4,exists][@party4,exists]Intervene

[Warrior - Arms - Intervene Member5]
@bind CTRL-SHIFT-3
/run GetLOS(UnitExists('raid5') and 'raid5' or 'player')
/cast [@raid5,exists][@player,exists]Intervene

[Warrior - Arms - Heroic Leap]
@bind CTRL-SHIFT-4
/cast Heroic Leap

[Warrior - Arms - Storm Bolt]
@bind CTRL-SHIFT-5
/stopcasting
/cast [@mouseover,harm][]Storm Bolt

[Warrior - Arms - Storm Bolt Focus]
@bind CTRL-SHIFT-6
/stopcasting
/cast [@focus]Storm Bolt

[Warrior - Arms - Storm Bolt Arena1]
@bind CTRL-SHIFT-7
/stopcasting
/cast [@arena1]Storm Bolt

[Warrior - Arms - Storm Bolt Arena2]
@bind CTRL-SHIFT-8
/stopcasting
/cast [@arena2]Storm Bolt

[Warrior - Arms - Storm Bolt Arena3]
@bind CTRL-SHIFT-9
/stopcasting
/cast [@arena3]Storm Bolt

[Warrior - Arms - Storm Bolt Arena4]
@bind CTRL-SHIFT-0
/stopcasting
/cast [@arena4]Storm Bolt

[Warrior - Arms - Storm Bolt Arena5]
@bind CTRL-SHIFT-A
/stopcasting
/cast [@arena5]Storm Bolt

[Warrior - Arms - Intimidating Shout]
@bind CTRL-SHIFT-B
/stopattack
/cast [@mouseover,harm][]Intimidating Shout

[Warrior - Arms - Intimidating Shout Arena1]
@bind CTRL-SHIFT-C
/cast [@arena1]Intimidating Shout

[Warrior - Arms - Intimidating Shout Arena2]
@bind CTRL-SHIFT-D
/cast [@arena2]Intimidating Shout

[Warrior - Arms - Intimidating Shout Arena3]
@bind CTRL-SHIFT-E
/cast [@arena3]Intimidating Shout

[Warrior - Arms - Intimidating Shout Arena4]
@bind CTRL-SHIFT-F
/cast [@arena4]Intimidating Shout

[Warrior - Arms - Intimidating Shout Arena5]
@bind CTRL-SHIFT-G
/cast [@arena5]Intimidating Shout

[Warrior - Arms - Thunder Clap]
@bind CTRL-SHIFT-H
/cast Thunder Clap

[Warrior - Arms - Spell Reflection]
@bind CTRL-SHIFT-I
/startattack
/stopcasting
/cast Spell Reflection

[Warrior - Arms - Rallying Cry]
@bind CTRL-SHIFT-J
/startattack
/cast Rallying Cry

[Warrior - Arms - Shockwave]
@bind CTRL-SHIFT-K
/cast Shockwave

[Warrior - Arms - Bitter Immunity]
@bind CTRL-SHIFT-L
/cast Bitter Immunity

[Warrior - Arms - Wrecking Throw | Shattering Throw]
@bind CTRL-SHIFT-M
/cast Wrecking Throw
/cast Shattering Throw

[Warrior - Arms - Piercing Howl]
@bind CTRL-SHIFT-N
/cast Piercing Howl

[Warrior - Arms - Thunderous Roar]
@bind CTRL-SHIFT-O
/cast Thunderous Roar

[Warrior - Arms - Avatar]
@bind CTRL-SHIFT-P
/startattack
/cast Avatar

[Warrior - Arms - Champion's Spear]
@bind CTRL-SHIFT-Q
/cast [combat,@player][]Champion's Spear

[Warrior - Arms - Sweeping Strikes]
@bind CTRL-SHIFT-R
/cast Sweeping Strikes

[Warrior - Arms - Cleave]
@bind CTRL-SHIFT-S
/cast Cleave

[Warrior - Arms - Demolish]
@bind CTRL-SHIFT-T
/cast Demolish

[Warrior - Arms - Die by the Sword]
@bind CTRL-SHIFT-U
/cast Die by the Sword

[Warrior - Arms - Ignore Pain]
@bind CTRL-SHIFT-V
/startattack
/cast Ignore Pain

[Warrior - Arms - Mortal Strike]
@bind CTRL-SHIFT-W
/cast Mortal Strike

[Warrior - Arms - Overpower]
@bind CTRL-SHIFT-X
/cast Overpower

[Warrior - Arms - Bladestorm | Ravager]
@bind CTRL-SHIFT-Y
/cast Bladestorm
/cast [combat,@player][]Ravager

[Warrior - Arms - Rend]
@bind CTRL-SHIFT-Z
/cast Rend

[Warrior - Arms - Rend Arena1]
@bind CTRL-ALT-SHIFT-1
/cast [@arena1]Rend

[Warrior - Arms - Rend Arena2]
@bind CTRL-ALT-SHIFT-2
/cast [@arena2]Rend

[Warrior - Arms - Rend Arena3]
@bind CTRL-ALT-SHIFT-3
/cast [@arena3]Rend

[Warrior - Arms - Rend Arena4]
@bind CTRL-ALT-SHIFT-4
/cast [@arena4]Rend

[Warrior - Arms - Rend Arena5]
@bind CTRL-ALT-SHIFT-5
/cast [@arena5]Rend

[Warrior - Arms - Skullsplitter]
@bind CTRL-ALT-SHIFT-6
/cast Skullsplitter

[Warrior - Arms - Warbreaker | Colossus Smash]
@bind CTRL-ALT-SHIFT-7
/cast Warbreaker
/cast Colossus Smash

[Warrior - Arms - Disarm]
@bind CTRL-ALT-SHIFT-8
/stopcasting
/cast [@mouseover,harm][]Disarm

[Warrior - Arms - Disarm Arena1]
@bind CTRL-ALT-SHIFT-9
/stopcasting
/cast [@arena1]Disarm

[Warrior - Arms - Disarm Arena2]
@bind CTRL-ALT-SHIFT-0
/stopcasting
/cast [@arena2]Disarm

[Warrior - Arms - Disarm Arena3]
@bind CTRL-ALT-SHIFT-A
/stopcasting
/cast [@arena3]Disarm

[Warrior - Arms - Disarm Arena4]
@bind CTRL-ALT-SHIFT-B
/stopcasting
/cast [@arena4]Disarm

[Warrior - Arms - Disarm Arena5]
@bind CTRL-ALT-SHIFT-C
/stopcasting
/cast [@arena5]Disarm

[Warrior - Arms - Duel]
@bind CTRL-ALT-SHIFT-D
/startattack
/cast Duel

[Warrior - Arms - Duel Arena1]
@bind CTRL-ALT-SHIFT-E
/cast [@arena1]Duel

[Warrior - Arms - Duel Arena2]
@bind CTRL-ALT-SHIFT-F
/cast [@arena2]Duel

[Warrior - Arms - Duel Arena3]
@bind CTRL-ALT-SHIFT-G
/cast [@arena3]Duel

[Warrior - Arms - Duel Arena4]
@bind CTRL-ALT-SHIFT-H
/cast [@arena4]Duel

[Warrior - Arms - Duel Arena5]
@bind CTRL-ALT-SHIFT-I
/cast [@arena5]Duel

[Warrior - Arms - Sharpen Blade]
@bind CTRL-ALT-SHIFT-J
/startattack
/cast Sharpen Blade

[Warrior - Arms - Human Racial]
@bind CTRL-ALT-SHIFT-K
/cast Human Racial

[Warrior - Arms - Stoneform]
@bind CTRL-ALT-SHIFT-L
/cast Stoneform

[Warrior - Arms - Shadowmeld]
@bind CTRL-ALT-SHIFT-M
/cast Shadowmeld

[Warrior - Arms - Escape Artist]
@bind CTRL-ALT-SHIFT-N
/cast Escape Artist

[Warrior - Arms - Gift of the Naaru]
@bind CTRL-ALT-SHIFT-O
/cast [@mouseover,help][@focus,help][]Gift of the Naaru

[Warrior - Arms - Darkflight]
@bind CTRL-ALT-SHIFT-P
/cast Darkflight

[Warrior - Arms - Blood Fury]
@bind CTRL-ALT-SHIFT-Q
/cast Blood Fury

[Warrior - Arms - Will of the Forsaken]
@bind CTRL-ALT-SHIFT-R
/cast Will of the Forsaken

[Warrior - Arms - War Stomp]
@bind CTRL-ALT-SHIFT-S
/cast War Stomp

[Warrior - Arms - Berserking]
@bind CTRL-ALT-SHIFT-T
/cast Berserking

[Warrior - Arms - Arcane Torrent]
@bind CTRL-ALT-SHIFT-U
/cast Arcane Torrent

[Warrior - Arms - Rocket Jump]
@bind CTRL-ALT-SHIFT-V
/cast Rocket Jump

[Warrior - Arms - Rocket Barrage]
@bind CTRL-ALT-SHIFT-W
/cast Rocket Barrage

[Warrior - Arms - Quaking Palm]
@bind CTRL-ALT-SHIFT-X
/cast [@mouseover,harm][]Quaking Palm

[Warrior - Arms - Spatial Rift]
@bind CTRL-ALT-SHIFT-Y
/cast Spatial Rift

[Warrior - Arms - Light's Judgment]
@bind CTRL-ALT-SHIFT-Z
/cast Light's Judgment

[Warrior - Arms - Fireblood]
@bind ALT-1
/cast Fireblood

[Warrior - Arms - Arcane Pulse]
@bind ALT-2
/cast Arcane Pulse

[Warrior - Arms - Bull Rush]
@bind ALT-3
/cast Bull Rush

[Warrior - Arms - Ancestral Call]
@bind ALT-4
/cast Ancestral Call

[Warrior - Arms - Haymaker]
@bind ALT-5
/cast [@mouseover,harm][]Haymaker

[Warrior - Arms - Regeneratin]
@bind ALT-6
/cast Regeneratin

[Warrior - Arms - Bag of Tricks]
@bind ALT-7
/cast [nocombat]Rummage Your Bag;[combat,@mouseover,exists][combat]Bag of Tricks

[Warrior - Arms - Hyper Organic Light Originator]
@bind ALT-8
/cast Hyper Organic Light Originator

[Warrior - Arms - Azerite Surge]
@bind ALT-9
/cast Azerite Surge

[Warrior - Arms - Rotation]
@bind ALT-0
/cast Rotation

[Warrior - Arms - Target Member1]
@bind ALT-A
/focus [mod:ctrl]raidpet1; [mod:alt]party1; raid1

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member2]
@bind ALT-B
/focus [mod:ctrl]raidpet2; [mod:alt]party2; raid2

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member3]
@bind ALT-C
/focus [mod:ctrl]raidpet3; [mod:alt]party3; raid3

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member4]
@bind ALT-D
/focus [mod:ctrl]raidpet4; [mod:alt]party4; raid4

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member5]
@bind ALT-E
/focus [mod:ctrl]raidpet5; [mod:alt]player; raid5

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member6]
@bind ALT-F
/focus [mod:ctrl]raidpet6; [mod:alt]focus; raid6

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member7]
@bind ALT-G
/focus [mod:ctrl]raidpet7; [mod:alt]partypet1; raid7

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member8]
@bind ALT-H
/focus [mod:ctrl]raidpet8; [mod:alt]partypet2; raid8

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member9]
@bind ALT-I
/focus [mod:ctrl]raidpet9; [mod:alt]partypet3; raid9

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member10]
@bind ALT-J
/focus [mod:ctrl]raidpet10; [mod:alt]partypet4; raid10

Note: Don't use ALT CTRL to bind this key!

[Warrior - Arms - Target Member11]
@bind ALT-K
/focus [mod:ctrl]raidpet11; raid11

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member12]
@bind ALT-L
/focus [mod:ctrl]raidpet12; raid12

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member13]
@bind ALT-M
/focus [mod:ctrl]raidpet13; raid13

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member14]
@bind ALT-N
/focus [mod:ctrl]raidpet14; raid14

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member15]
@bind ALT-O
/focus [mod:ctrl]raidpet15; raid15

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member16]
@bind ALT-P
/focus [mod:ctrl]raidpet16; raid16

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member17]
@bind ALT-Q
/focus [mod:ctrl]raidpet17; raid17

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member18]
@bind ALT-R
/focus [mod:ctrl]raidpet18; raid18

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member19]
@bind ALT-S
/focus [mod:ctrl]raidpet19; raid19

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member20]
@bind ALT-T
/focus [mod:ctrl]raidpet20; raid20

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member21]
@bind ALT-U
/focus [mod:ctrl]raidpet21; raid21

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member22]
@bind ALT-V
/focus [mod:ctrl]raidpet22; raid22

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member23]
@bind ALT-W
/focus [mod:ctrl]raidpet23; raid23

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member24]
@bind ALT-X
/focus [mod:ctrl]raidpet24; raid24

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member25]
@bind ALT-Y
/focus [mod:ctrl]raidpet25; raid25

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member26]
@bind ALT-Z
/focus [mod:ctrl]raidpet26; raid26

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member27]
@bind CTRL-1
/focus [mod:ctrl]raidpet27; raid27

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member28]
@bind CTRL-2
/focus [mod:ctrl]raidpet28; raid28

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member29]
@bind CTRL-3
/focus [mod:ctrl]raidpet29; raid29

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member30]
@bind CTRL-4
/focus [mod:ctrl]raidpet30; raid30

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member31]
@bind CTRL-5
/focus [mod:ctrl]raidpet31; raid31

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member32]
@bind CTRL-6
/focus [mod:ctrl]raidpet32; raid32

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member33]
@bind CTRL-7
/focus [mod:ctrl]raidpet33; raid33

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member34]
@bind CTRL-8
/focus [mod:ctrl]raidpet34; raid34

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member35]
@bind CTRL-9
/focus [mod:ctrl]raidpet35; raid35

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member36]
@bind CTRL-0
/focus [mod:ctrl]raidpet36; raid36

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member37]
@bind CTRL-A
/focus [mod:ctrl]raidpet37; raid37

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member38]
@bind CTRL-B
/focus [mod:ctrl]raidpet38; raid38

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member39]
@bind CTRL-C
/focus [mod:ctrl]raidpet39; raid39

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Target Member40]
@bind CTRL-D
/focus [mod:ctrl]raidpet40; raid40

Note: Don't use CTRL to bind this key!

[Warrior - Arms - Secondary Rotation]
@bind CTRL-E
/cast Secondary Rotation

[Warrior - Arms - Trinket Rotation]
@bind CTRL-F
/cast Trinket Rotation

[Warrior - Arms - AntiFake CC]
@bind CTRL-G
/cast AntiFake CC

[Warrior - Arms - AntiFake CC Focus]
@bind CTRL-H
/cast AntiFake CC Focus

[Warrior - Arms - AntiFake Interrupt]
@bind CTRL-I
/cast AntiFake Interrupt

[Warrior - Arms - AntiFake Interrupt Focus]
@bind CTRL-J
/cast AntiFake Interrupt Focus

[Warrior - Arms - AntiFake CC2]
@bind CTRL-K
/cast AntiFake CC2

[Warrior - Arms - AntiFake CC2 Focus]
@bind CTRL-L
/cast AntiFake CC2 Focus

[Warrior - Arms - Universal1]
@bind CTRL-M
/cast Universal1

[Warrior - Arms - Universal2]
@bind CTRL-N
/cast Universal2

[Warrior - Arms - Universal3]
@bind CTRL-O
/cast Universal3

[Warrior - Arms - Universal4]
@bind CTRL-P
/cast Universal4

[Warrior - Arms - Universal5]
@bind CTRL-Q
/cast Universal5

[Warrior - Arms - Universal6]
@bind CTRL-R
/cast Universal6

[Warrior - Arms - Universal7]
@bind CTRL-S
/cast Universal7

[Warrior - Arms - Universal8]
@bind CTRL-T
/cast Universal8

[Warrior - Arms - Universal9]
@bind CTRL-U
/cast Universal9

[Warrior - Arms - Universal10]
@bind CTRL-V
/cast Universal10

[Warrior - Arms - Universal1 Unit1]
@bind CTRL-W
/cast Universal1 Unit1

[Warrior - Arms - Universal1 Unit2]
@bind CTRL-X
/cast Universal1 Unit2

[Warrior - Arms - Universal1 Unit3]
@bind CTRL-Y
/cast Universal1 Unit3

[Warrior - Arms - Universal1 Unit4]
@bind CTRL-Z
/cast Universal1 Unit4

[Warrior - Arms - Universal1 Unit5]
@bind SHIFT-1
/cast Universal1 Unit5

[Warrior - Arms - Universal2 Unit1]
@bind SHIFT-2
/cast Universal2 Unit1

[Warrior - Arms - Universal2 Unit2]
@bind SHIFT-3
/cast Universal2 Unit2

[Warrior - Arms - Universal2 Unit3]
@bind SHIFT-4
/cast Universal2 Unit3

[Warrior - Arms - Universal2 Unit4]
@bind SHIFT-5
/cast Universal2 Unit4

[Warrior - Arms - Universal2 Unit5]
@bind SHIFT-6
/cast Universal2 Unit5

[Warrior - Arms - Universal3 Unit1]
@bind SHIFT-7
/cast Universal3 Unit1

[Warrior - Arms - Universal3 Unit2]
@bind SHIFT-8
/cast Universal3 Unit2

[Warrior - Arms - Universal3 Unit3]
@bind SHIFT-9
/cast Universal3 Unit3

[Warrior - Arms - Universal3 Unit4]
@bind SHIFT-0
/cast Universal3 Unit4

[Warrior - Arms - Universal3 Unit5]
@bind SHIFT-A
/cast Universal3 Unit5

[Warrior - Arms - Universal4 Unit1]
@bind SHIFT-B
/cast Universal4 Unit1

[Warrior - Arms - Universal4 Unit2]
@bind SHIFT-C
/cast Universal4 Unit2

[Warrior - Arms - Universal4 Unit3]
@bind SHIFT-D
/cast Universal4 Unit3

[Warrior - Arms - Universal4 Unit4]
@bind SHIFT-E
/cast Universal4 Unit4

[Warrior - Arms - Universal4 Unit5]
@bind SHIFT-F
/cast Universal4 Unit5

[Warrior - Arms - Universal5 Unit1]
@bind SHIFT-G
/cast Universal5 Unit1

[Warrior - Arms - Universal5 Unit2]
@bind SHIFT-H
/cast Universal5 Unit2

[Warrior - Arms - Universal5 Unit3]
@bind SHIFT-I
/cast Universal5 Unit3

[Warrior - Arms - Universal5 Unit4]
@bind SHIFT-J
/cast Universal5 Unit4

[Warrior - Arms - Universal5 Unit5]
@bind SHIFT-K
/cast Universal5 Unit5

[Warrior - Arms - Universal6 Unit1]
@bind SHIFT-L
/cast Universal6 Unit1

[Warrior - Arms - Universal6 Unit2]
@bind SHIFT-M
/cast Universal6 Unit2

[Warrior - Arms - Universal6 Unit3]
@bind SHIFT-N
/cast Universal6 Unit3

[Warrior - Arms - Universal6 Unit4]
@bind SHIFT-O
/cast Universal6 Unit4

[Warrior - Arms - Universal6 Unit5]
@bind SHIFT-P
/cast Universal6 Unit5

[Warrior - Arms - Universal7 Unit1]
@bind SHIFT-Q
/cast Universal7 Unit1

[Warrior - Arms - Universal7 Unit2]
@bind SHIFT-R
/cast Universal7 Unit2

[Warrior - Arms - Universal7 Unit3]
@bind SHIFT-S
/cast Universal7 Unit3

[Warrior - Arms - Universal7 Unit4]
@bind SHIFT-T
/cast Universal7 Unit4

[Warrior - Arms - Universal7 Unit5]
@bind SHIFT-U
/cast Universal7 Unit5

[Warrior - Arms - Universal8 Unit1]
@bind SHIFT-V
/cast Universal8 Unit1

[Warrior - Arms - Universal8 Unit2]
@bind SHIFT-W
/cast Universal8 Unit2

[Warrior - Arms - Universal8 Unit3]
@bind SHIFT-X
/cast Universal8 Unit3

[Warrior - Arms - Universal8 Unit4]
@bind SHIFT-Y
/cast Universal8 Unit4

[Warrior - Arms - Universal8 Unit5]
@bind SHIFT-Z
/cast Universal8 Unit5

[Warrior - Arms - Universal9 Unit1]
@bind CTRL-ALT-1
/cast Universal9 Unit1

[Warrior - Arms - Universal9 Unit2]
@bind CTRL-ALT-2
/cast Universal9 Unit2

[Warrior - Arms - Universal9 Unit3]
@bind CTRL-ALT-3
/cast Universal9 Unit3

[Warrior - Arms - Universal9 Unit4]
@bind CTRL-ALT-4
/cast Universal9 Unit4

[Warrior - Arms - Universal9 Unit5]
@bind CTRL-ALT-5
/cast Universal9 Unit5

[Warrior - Arms - Universal10 Unit1]
@bind CTRL-ALT-6
/cast Universal10 Unit1

[Warrior - Arms - Universal10 Unit2]
@bind CTRL-ALT-7
/cast Universal10 Unit2

[Warrior - Arms - Universal10 Unit3]
@bind CTRL-ALT-8
/cast Universal10 Unit3

[Warrior - Arms - Universal10 Unit4]
@bind CTRL-ALT-9
/cast Universal10 Unit4

[Warrior - Arms - Universal10 Unit5]
@bind CTRL-ALT-0
/cast Universal10 Unit5

[Warrior - Arms - Every Man for Himself]
@bind CTRL-ALT-A
/cast Every Man for Himself

[Warrior - Arms - Dark Flight]
@bind CTRL-ALT-B
/cast Dark Flight

[Warrior - Arms - Ravager]
@bind CTRL-ALT-C
/cast Ravager

[Warrior - Arms - Warbreaker]
@bind CTRL-ALT-D
/cast Warbreaker

[Warrior - Arms - Colossus Smash]
@bind CTRL-ALT-E
/cast Colossus Smash

[Warrior - Arms - Test of Might]
@bind CTRL-ALT-F
/cast Test of Might

[Warrior - Arms - Bladestorm]
@bind CTRL-ALT-G
/cast Bladestorm

[Warrior - Arms - Tideof Blood]
@bind CTRL-ALT-H
/cast Tideof Blood

[Warrior - Arms - Battlelord]
@bind CTRL-ALT-I
/cast Battlelord

[Warrior - Arms - Unhinged]
@bind CTRL-ALT-J
/cast Unhinged

[Warrior - Arms - Fervorof Battle]
@bind CTRL-ALT-K
/cast Fervorof Battle

[Warrior - Arms - Heroic Strike]
@bind CTRL-ALT-L
/cast Heroic Strike

[Warrior - Arms - Impending Victory]
@bind CTRL-ALT-M
/cast Impending Victory

[Warrior - Arms - Wrecking Throw]
@bind CTRL-ALT-N
/cast Wrecking Throw

[Warrior - Arms - Massacre]
@bind CTRL-ALT-O
/cast Massacre

[Warrior - Arms - Sonic Boom]
@bind CTRL-ALT-P
/cast Sonic Boom

[Warrior - Arms - Bloodand Thunder]
@bind CTRL-ALT-Q
/cast Bloodand Thunder

[Warrior - Arms - Blademasters Torment]
@bind CTRL-ALT-R
/cast Blademasters Torment

[Warrior - Arms - Stormof Swords]
@bind CTRL-ALT-S
/cast Stormof Swords

[Warrior - Arms - Crushing Force]
@bind CTRL-ALT-T
/cast Crushing Force

[Warrior - Arms - Warlords Torment]
@bind CTRL-ALT-U
/cast Warlords Torment

[Warrior - Arms - Bloodletting]
@bind CTRL-ALT-V
/cast Bloodletting

[Warrior - Arms - Improved Slam]
@bind CTRL-ALT-W
/cast Improved Slam

[Warrior - Arms - Merciless Bonegrinder]
@bind CTRL-ALT-X
/cast Merciless Bonegrinder

[Warrior - Arms - Strengthof Arms]
@bind CTRL-ALT-Y
/cast Strengthof Arms

[Warrior - Arms - Executioners Precision]
@bind CTRL-ALT-Z
/cast Executioners Precision

[Warrior - Arms - Juggernaut]
@bind 1
/cast Juggernaut

[Warrior - Arms - Fierce Followthrough]
@bind 2
/cast Fierce Followthrough

[Warrior - Arms - Slayers Dominance]
@bind 3
/cast Slayers Dominance

[Warrior - Arms - Pummel]
@bind 4
/cast Pummel

[Warrior - Arms - Seethe]
@bind 5
/cast Seethe

[Warrior - Arms - Overwatch]
@bind 6
/cast Overwatch

[Warrior - Arms - Shattering Throw]
@bind 7
/cast Shattering Throw

[Warrior - Arms - Enduring Rage]
@bind 8
/cast Enduring Rage

[Warrior - Arms - Bloodrage]
@bind 9
/cast Bloodrage

[Warrior - Arms - Death Wish]
@bind 0
/cast Death Wish

[Warrior - Arms - Demolition]
@bind A
/cast Demolition

[Warrior - Arms - War Banner]
@bind B
/cast War Banner

[Warrior - Arms - Dreadnaught]
@bind C
/cast Dreadnaught

[Warrior - Arms - Anger Management]
@bind D
/cast Anger Management

[Warrior - Arms - Improved Sweeping Strikes]
@bind E
/cast Improved Sweeping Strikes

[Warrior - Arms - Sharpened Blades]
@bind F
/cast Sharpened Blades

[Warrior - Arms - Berserker Rage]
@bind G
/cast Berserker Rage

[Warrior - Arms - Victory Rush]
@bind H
/cast Victory Rush

[Warrior - Arms - Frozen Binds]
@bind I
/cast Frozen Binds

[Warrior - Arms - Sanguine]
@bind J
/cast Sanguine

[Warrior - Arms - Sated]
@bind K
/cast Sated

[Warrior - Arms - SBA]
@bind L
/cast SBA

[Warrior - Arms - Blessing of Protection]
@bind M
/cast Blessing of Protection

[Warrior - Arms - Dark Pact]
@bind N
/cast Dark Pact

[Warrior - Arms - Combustion]
@bind O
/cast Combustion

[Warrior - Arms - Icy Veins]
@bind P
/cast Icy Veins

[Warrior - Arms - Alter Time]
@bind Q
/cast Alter Time

[Warrior - Arms - Arcane Power]
@bind R
/cast Arcane Power

[Warrior - Arms - Divine Favor]
@bind S
/cast Divine Favor

[Warrior - Arms - Blessing of Freedom]
@bind T
/cast Blessing of Freedom

[Warrior - Arms - Power Infusion]
@bind U
/cast Power Infusion

[Warrior - Arms - Survival Tactics]
@bind V
/cast Survival Tactics

[Warrior - Arms - Cloak of Shadows]
@bind W
/cast Cloak of Shadows

[Warrior - Arms - Reflect]
@bind X
/cast Reflect

[Warrior - Arms - Devouring Plague]
@bind Y
/cast Devouring Plague

[Warrior - Arms - Aspect of the Turtle]
@bind Z
/cast Aspect of the Turtle

[Warrior - Arms - Divine Shield]
@bind ALT-SHIFT-F1
/cast Divine Shield

[Warrior - Arms - Ice Block]
@bind ALT-SHIFT-F2
/cast Ice Block

[Warrior - Arms - Slaughterhouse]
@bind ALT-SHIFT-F3
/cast Slaughterhouse

[Warrior - Arms - Death Sentence]
@bind ALT-SHIFT-F4
/cast Death Sentence

[Warrior - Arms - Battle Trance]
@bind ALT-SHIFT-F5
/cast Battle Trance

[Warrior - Arms - Barbarian]
@bind ALT-SHIFT-F6
/cast Barbarian
]==]
